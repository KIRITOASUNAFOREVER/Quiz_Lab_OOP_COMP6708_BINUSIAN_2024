package MyPhoneContact;

import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

public class MyPhoneContact {
	Scanner scan = new Scanner(System.in);
	Vector<Contact> contactList = new Vector<>();
	
	private boolean checkOwnerName(String OwnerName) {
		if(OwnerName.startsWith("Mr.") || OwnerName.startsWith("Mrs.")) {
			return true;
		}else {
			return false;
		}
	}
	
	private boolean checkPhoneType(String PhoneType) {
		if(PhoneType.equalsIgnoreCase("Work") || PhoneType.equalsIgnoreCase("Home") || PhoneType.equalsIgnoreCase("Mobile")) {
			return true;
		}else {
			return false;
		}
	}
	
	private boolean checkPhoneContact(int PhoneContact) {
		if(PhoneContact >= 1 && PhoneContact <= 20) {
			return true;
		}else {
			return false;
		}
	}
	
	private String generatePhoneNumber() {
		String PhonesNumber;
		Random rand = new Random();
		int number1 = rand.nextInt(10);
		int number2 = rand.nextInt(10);
		int number3 = rand.nextInt(10);
		int number4 = rand.nextInt(10);
		int number5 = rand.nextInt(10);
		int number6 = rand.nextInt(10);
		int number7 = rand.nextInt(10);
		int number8 = rand.nextInt(10);
		int number9 = rand.nextInt(10);
		int number10 = rand.nextInt(10);
		PhonesNumber = "08" + number1 + number2 + number3 + number4 + number5 + number6 + number7 + number8 + number9 + number10;
		
		return PhonesNumber;
	}
	
	int PhoneContact;
	public MyPhoneContact() {
		System.out.println("Input Phone");
		System.out.println("===========");
		
		String OwnerName;
		do {
			System.out.print("Input your owner name (startwith \"Mr.\" or \"Mrs.\"): ");
			OwnerName = scan.nextLine();
		}while(!checkOwnerName(OwnerName));
		
		String PhoneType;
		do {
			System.out.print("Input your phone type [ Work | Home | Mobile ](insensitive) : ");
			PhoneType = scan.nextLine();
		}while(!checkPhoneType(PhoneType));
		PhoneType = PhoneType.toLowerCase();
        String firstLetter = PhoneType.substring(0, 1);
        String remainingLetters = PhoneType.substring(1, PhoneType.length());
        firstLetter = firstLetter.toUpperCase();
        PhoneType = firstLetter.concat(remainingLetters);
		
        do {
        	System.out.print("Input your storage contact [1 - 20](inclusive) : ");
        	PhoneContact = scan.nextInt(); scan.nextLine();
        }while(!checkPhoneContact(PhoneContact));
        
        String OwnerPhoneNumber;
        OwnerPhoneNumber = generatePhoneNumber();
        
        System.out.println(); System.out.println();
        MainMenu(OwnerName, PhoneType, PhoneContact, OwnerPhoneNumber);
	}
	
	int totalContacs = 0;
	private void MainMenu(String OwnerName, String PhoneType, int PhoneContact, String OwnerPhoneNumber) {
		int pilihan;
		
		do {
			System.out.println("About this Phone");
			System.out.println("================");
			System.out.println("Phone owner name                             : " + OwnerName);
			System.out.println("This Phone Number                            : " + OwnerPhoneNumber);
			System.out.println("This Phone Type                              : " + PhoneType);
			System.out.println("This Phone Storage Contact                   : " + totalContacs +"/" + PhoneContact);
			System.out.println(); System.out.println();
			
			System.out.println("1. View All Contact");
			System.out.println("2. Add Contact");
			System.out.println("3. Delete Contact");
			System.out.println("4. Search Contact");
			System.out.println("5. Exit");
			System.out.print(">> ");
			pilihan = scan.nextInt(); scan.nextLine();
			
			switch(pilihan) {
			case 1:
				viewAllContact();
				break;
			case 2:
				addContact();
				break;
			case 3:
				deleteContact();
				break;
			case 4:
				searchContact();
				break;
			}
		}while(pilihan < 1 || pilihan > 5 || pilihan != 5);
	}
	
	private void viewAllContact() {
		int jumlah = contactList.size();
		
		if(jumlah == 0) {
			System.out.println("There is no contact");
			System.out.print("Press enter to continue...");
			scan.nextLine();
			System.out.println(); System.out.println();
			return;
		}
		
		System.out.println("Contact List");
		System.out.println("============");
		System.out.println();
		for (int k = 0; k < jumlah; k++) {
			System.out.println("Contact Name          : " + contactList.get(k).getContactName());
			System.out.println("Contact Phone Number  : " + contactList.get(k).getContactPhoneNumber());
			System.out.println("Contact Email         : " + contactList.get(k).getContactEmail());
			System.out.println(); System.out.println();
		}
		
		System.out.print("Press enter to continue...");
		scan.nextLine();
		System.out.println(); System.out.println();
	}
	
	private boolean checkContactName(String ContactName) {
		if(ContactName.startsWith("Mr.") || ContactName.startsWith("Mrs.")) {
			return true;
		}else {
			return false;
		}
	}
	
	private boolean checkPhoneNumber(String PhoneNumber) {
		int panjang = PhoneNumber.length();
		
		for (int i = 0; i < panjang; i++) {
			if(PhoneNumber.charAt(0) == '-') {
				return false;
			}
			if(!(PhoneNumber.charAt(i) >= 48 && PhoneNumber.charAt(i) <= 57)) {
				return false;
			}
		}
		
		if(panjang == 12) {
			return true;
		}else {
			return false;
		}
	}
	
	private boolean checkContactEmail(String ContactEmail) {
		int panjang  = ContactEmail.length();
		int jumlahAT = 0;
		int jumlahDOT = 0;
		
		for (int j = 0; j < panjang; j++) {
			if(ContactEmail.charAt(j) == '@') {
				jumlahAT = jumlahAT + 1;
			}
			if(ContactEmail.charAt(j) == '.') {
				jumlahDOT = jumlahDOT + 1;
			}
			if(j != (panjang - 1)) {
				if(ContactEmail.charAt(j) == '@' && ContactEmail.charAt(j+1) == '.') {
					return false;
				}
			}
		}
		
		if(jumlahAT > 1) {
			return false;
		}else {
			if(jumlahDOT == 0) {
				return false;
			}else{
				return true;
			}
		}
	}
	
	private void addContact() {
		if(totalContacs >= PhoneContact) {
			System.out.println("The storage is full!");
			System.out.print("Press enter to continue...");
			scan.nextLine();
			System.out.println(); System.out.println();
			return;
		}
		
		String ContactName;
		do {
			System.out.print("Input contact name (startwith \"Mr.\" or \"Mrs.\"): ");
			ContactName = scan.nextLine();
		}while(!checkContactName(ContactName));
		
		String PhoneNumber;
		do {
			System.out.print("Input contact phone number [12 digits] : ");
			PhoneNumber = scan.nextLine();
		}while(!checkPhoneNumber(PhoneNumber));
		
		String ContactEmail;
		do {
			System.out.print("Input email of this contact : ");
			ContactEmail = scan.nextLine();
		}while(!checkContactEmail(ContactEmail));
		
		contactList.add(new Contact(ContactName, PhoneNumber, ContactEmail));
		totalContacs = totalContacs + 1;
	}
	
	private boolean checkIndexDeleteLength(int IndexDelete) {
		int jumlah = contactList.size();
		
		if(IndexDelete < 1 || IndexDelete > jumlah) {
			return false;
		}
		
		return true;
	}
	
	private void deleteContact() {
		int jumlah = contactList.size();
		
		if(jumlah == 0) {
			System.out.println("There is no contact");
			System.out.print("Press enter to continue...");
			scan.nextLine();
			System.out.println(); System.out.println();
			return;
		}
		
		System.out.println("Contact List");
		System.out.println("============");
		System.out.println();
		for (int m = 0; m < jumlah; m++) {
			System.out.println("(No. " + (m+1) + ")");
			System.out.println("Contact Name          : " + contactList.get(m).getContactName());
			System.out.println("Contact Phone Number  : " + contactList.get(m).getContactPhoneNumber());
			System.out.println();
		}
		
		int indexDelete;
		do {
			System.out.print("Select which contact no. you want to remove [1-" + jumlah +"]: ");
			indexDelete = scan.nextInt(); scan.nextLine();
		}while(!checkIndexDeleteLength(indexDelete));
		
		contactList.remove(indexDelete-1);
		totalContacs = totalContacs - 1;
		
		System.out.println();
		System.out.println("Contact successfully removed.");
		System.out.print("Press enter to continue...");
		scan.nextLine();
		System.out.println(); System.out.println();
		
		
	}
	
	private boolean checkCariNama(String CariNama) {
		if(CariNama.isEmpty()) {
			return false;
		}else {
			return true;
		}
	}
	
	private void searchContact() {
		int jumlah = contactList.size();
		
		if(jumlah == 0) {
			System.out.println("There is no contact");
			System.out.print("Press enter to continue...");
			scan.nextLine();
			System.out.println(); System.out.println();
			return;
		}
		
		String cariNama;
		do {
			System.out.print("Input name of contact to search : ");
			cariNama = scan.nextLine();
		}while(!checkCariNama(cariNama));
		
		int jumlahKetemu = 0;
		System.out.println();
		System.out.println("Search Result");
		System.out.println("=============");
		for (int n = 0; n < jumlah; n++) {
			if(contactList.get(n).getContactName().contains(cariNama)) {
				System.out.println((jumlahKetemu+1) + ". " + contactList.get(n).getContactName());
				jumlahKetemu = jumlahKetemu + 1;
			}
		}
		System.out.println();
		if(jumlahKetemu == 0) {
			System.out.println("no contact found!");
		}else if(jumlahKetemu == 1) {
			System.out.println(jumlahKetemu + " contact found!");
		}else if(jumlahKetemu > 1) {
			System.out.println(jumlahKetemu + " contact(s) found!");
		}
		
		System.out.println();
		System.out.print("Press enter to continue...");
		scan.nextLine();
		System.out.println(); System.out.println();
	}

	public static void main(String[] args) {
		new MyPhoneContact();
	}
}