package MyPhoneContact;

public class Contact {
	String contactName;
	String contactPhoneNumber;
	String contactEmail;
	
	public Contact(String contactName, String contactPhoneNumber, String contactEmail) {
		super();
		this.contactName = contactName;
		this.contactPhoneNumber = contactPhoneNumber;
		this.contactEmail = contactEmail;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactPhoneNumber() {
		return contactPhoneNumber;
	}

	public void setContactPhoneNumber(String contactPhoneNumber) {
		this.contactPhoneNumber = contactPhoneNumber;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}
}
