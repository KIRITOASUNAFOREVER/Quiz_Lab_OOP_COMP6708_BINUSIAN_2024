package CompShop31;

public class Transaction {
	String transactionID;
	String customerName;
	String customerAddress;
	String processorBrand;
	String pcGPU;
	int ramSize;
	int storageSize;
	double pcPrice;
	
	public Transaction(String transactionID, String customerName, String customerAddress, String processorBrand,
			String pcGPU, int ramSize, int storageSize, double pcPrice) {
		super();
		this.transactionID = transactionID;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.processorBrand = processorBrand;
		this.pcGPU = pcGPU;
		this.ramSize = ramSize;
		this.storageSize = storageSize;
		this.pcPrice = pcPrice;
	}

	public String getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getProcessorBrand() {
		return processorBrand;
	}

	public void setProcessorBrand(String processorBrand) {
		this.processorBrand = processorBrand;
	}

	public String getPcGPU() {
		return pcGPU;
	}

	public void setPcGPU(String pcGPU) {
		this.pcGPU = pcGPU;
	}

	public int getRamSize() {
		return ramSize;
	}

	public void setRamSize(int ramSize) {
		this.ramSize = ramSize;
	}

	public int getStorageSize() {
		return storageSize;
	}

	public void setStorageSize(int storageSize) {
		this.storageSize = storageSize;
	}

	public double getPcPrice() {
		return pcPrice;
	}

	public void setPcPrice(double pcPrice) {
		this.pcPrice = pcPrice;
	}
}
