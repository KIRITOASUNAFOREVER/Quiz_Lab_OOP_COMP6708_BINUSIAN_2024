package CompShop31;

import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

public class CompShop31 {
	Scanner scan = new Scanner(System.in);
	Vector<Transaction> transactionList = new Vector<>();
	
	private boolean checkPilihanNumber(String PilihanNumber) {
		int panjang = PilihanNumber.length();
		
		for (int i = 0; i < panjang; i++) {
			if(!(PilihanNumber.charAt(i) >= 48 && PilihanNumber.charAt(i) <= 57)) {
				return false;
			}
		}
		return true;
	}
	
	private int menu() {
		String pilihan;
		
		System.out.println("Comp Shop 31");
		System.out.println("===============");
		System.out.println("1. Buy PC");
		System.out.println("2. View Transaction");
		System.out.println("3. Remove Transaction");
		System.out.println("4. Exit");
		do {
			System.out.print(">> ");
			pilihan = scan.nextLine();
			
			if(!checkPilihanNumber(pilihan)) {
				System.out.println("input must be a number!");
				System.out.println("input must be between 1-4!");
			}
		}while(!checkPilihanNumber(pilihan));
		int pilihanNumbers = Integer.parseInt(pilihan);
		while(pilihanNumbers < 1 || pilihanNumbers > 4) {
			System.out.println("input must be between 1-4!");
			pilihanNumbers = 0;
			do {
				System.out.print(">> ");
				pilihan = scan.nextLine();
				
				if(!checkPilihanNumber(pilihan)) {
					System.out.println("input must be a number!");
					System.out.println("input must be between 1-4!");
				}
			}while(!checkPilihanNumber(pilihan));
			pilihanNumbers = Integer.parseInt(pilihan);
		}
		
		return pilihanNumbers;
	}
	
	public CompShop31() {
		int hasilPilihan;
		
		do {
			hasilPilihan = menu();
			switch(hasilPilihan) {
				case 1:
					buyPC();
					break;
				case 2:
					viewTransaction();
					break;
				case 3:
					removeTransaction();
					break;
			}
		}while(hasilPilihan != 4);
	}
	
	private boolean checkProcessorBrand(String ProcessorBrand) {
		if(ProcessorBrand.equals("Intel") || ProcessorBrand.equals("AMD")) {
			return true;
		}else {
			return false;
		}
	}
	
	private boolean checkIntelProcessorInput(String IntelProcessorInput) {
		if(IntelProcessorInput.equals("12600K") || IntelProcessorInput.equals("12700K") || IntelProcessorInput.equals("12900K")) {
			return true;
		}else{
			return false;
		}
	}
	
	private String IntelProcessorInput(){
		String IntelProcessor;
		do {
			System.out.print("Input Intel processor [12600K | 12700K | 12900K] (case sensitive) : ");
			IntelProcessor = scan.nextLine();
		}while(!checkIntelProcessorInput(IntelProcessor));
		
		return IntelProcessor;
	}
	
	private boolean checkAMDProcessorInput(String AMDProcessorInput) {
		if(AMDProcessorInput.equals("5600X") || AMDProcessorInput.equals("5700X") || AMDProcessorInput.equals("5950X")) {
			return true;
		}else{
			return false;
		}
	}
	
	private String AMDProcessorInput() {
		String AMDProcessor;
		do {
			System.out.print("Input AMD processor [5600X | 5700X | 5950X] (case sensitive) : ");
			AMDProcessor = scan.nextLine();
		}while(!checkAMDProcessorInput(AMDProcessor));
		
		return AMDProcessor;
	}
	
	private boolean checkGPUInput(String GPUInput) {
		if(GPUInput.equals("RTX 2060") || GPUInput.equals("RTX 3070") || GPUInput.equals("GTX 1080")) {
			return true;
		}else{
			return false;
		}
	}
	
	private double getProcessorPrice(String FinalProcessorPrice) {
		double finalProcessorPrice = 0;
		if(FinalProcessorPrice.equals("12600K")) {
			finalProcessorPrice = 1000;
		}else if(FinalProcessorPrice.equals("12700K")) {
			finalProcessorPrice = 1100;
		}else if(FinalProcessorPrice.equals("12900K")) {
			finalProcessorPrice = 1200;
		}else if(FinalProcessorPrice.equals("5600X")) {
			finalProcessorPrice = 800;
		}else if(FinalProcessorPrice.equals("5700X")) {
			finalProcessorPrice = 900;
		}else if(FinalProcessorPrice.equals("5950X")) {
			finalProcessorPrice = 1000;
		}
		
		return finalProcessorPrice;
	}
	
	private double getGPUPrice(String FinalGPUPrice) {
		double finalGPUPrice = 0;
		if(FinalGPUPrice.equals("RTX 2060")) {
			finalGPUPrice = 2860;
		}else if(FinalGPUPrice.equals("RTX 3070")) {
			finalGPUPrice = 5650;
		}else if(FinalGPUPrice.equals("GTX 1080")) {
			finalGPUPrice = 1200;
		}
		
		return finalGPUPrice;
	}
	
	private boolean checkRamSize(int RamSize) {
		if(RamSize == 8 || RamSize == 16 || RamSize == 32) {
			return true;
		}else {
			return false;
		}
	}
	
	private boolean checkStorageSize(int StorageSize) {
		if(StorageSize == 500 || StorageSize == 1024 || StorageSize == 2048) {
			return true;
		}else {
			return false;
		}
	}
	
	private boolean checkCustomerName(String CustomerName) {
		if(CustomerName.isEmpty()) {
			return false;
		}
		
		return true;
	}
	
	private boolean checkCustomerAddress(String CustomerAddress) {
		if(CustomerAddress.startsWith("jl. ")) {
			return true;
		}else {
			return false;
		}
	}
	
	private String generateTransactionID() {
		String TransactionsID;
		Random rand = new Random();
		
		char character1 = (char)(rand.nextInt(26) + 'A');
		char character2 = (char)(rand.nextInt(26) + 'A');
		int number1 = rand.nextInt(10);
		int number2 = rand.nextInt(10);
		int number3 = rand.nextInt(10);
		TransactionsID = String.format("%c%c%d%d%d", character1, character2, number1, number2, number3);
		
		return TransactionsID;
	}
	
	private void buyPC() {
		System.out.println("Choose Computer Parts:");
		
		String ProcessorBrand;
		do {
			System.out.print("Choose processor brand [Intel|AMD] (case sensitive) : ");
			ProcessorBrand = scan.nextLine();
		}while(!checkProcessorBrand(ProcessorBrand));
		
		String FinalProcessor = "";
		if(ProcessorBrand.equals("Intel")) {
			FinalProcessor = IntelProcessorInput();
		}else if(ProcessorBrand.equals("AMD")) {
			FinalProcessor = AMDProcessorInput();
		}
		
		String pcGPU;
		do {
			System.out.print("Select GPU [RTX 2060 | RTX 3070 | GTX 1080] (case sensitive) : ");
			pcGPU = scan.nextLine();
		}while(!checkGPUInput(pcGPU));
		
		double ProcessorPrice;
		ProcessorPrice = getProcessorPrice(FinalProcessor);
		
		double GPUPrice;
		GPUPrice = getGPUPrice(pcGPU);
		
		double pcPrice;
		pcPrice = (1.1 * (ProcessorPrice + GPUPrice)) + 100;
		
		int RamSize;
		do {
			System.out.print("Input ram size [ 8 | 16 | 32 ] : ");
			RamSize = scan.nextInt(); scan.nextLine();
		}while(!checkRamSize(RamSize));
		
		int StorageSize;
		do {
			System.out.print("Input storage size [ 500 | 1024 | 2048 ] : ");
			StorageSize = scan.nextInt(); scan.nextLine();
		}while(!checkStorageSize(StorageSize));
		
		System.out.println(); System.out.println();
		System.out.println("Further Information");
		
		String CustomerName;
		do {
			System.out.print("Input Customer Name (cannot be empty): ");
			CustomerName = scan.nextLine();
		}while(!checkCustomerName(CustomerName));
		
		String CustomerAddress;
		do {
			System.out.print("Input Shipping Address (start with 'jl.'): ");
			CustomerAddress = scan.nextLine();
		}while(!checkCustomerAddress(CustomerAddress));
		
		String TransactionID;
		TransactionID = generateTransactionID();
		
		transactionList.add(new Transaction(TransactionID, CustomerName, CustomerAddress, FinalProcessor, pcGPU, RamSize, StorageSize, pcPrice));
		System.out.println();
		
		System.out.println("Transaction Success!!!");
		System.out.print("Press enter to continue...");
		scan.nextLine();
		System.out.println(); System.out.println();
	}
	
	private void viewTransaction() {
		int jumlah = transactionList.size();
		
		if(jumlah == 0) {
			System.out.println("There's no transaction available."); System.out.println();
			System.out.print("Press enter to continue...");
			scan.nextLine();
			System.out.println(); System.out.println();
			return;
		}
		for (int i = 0; i < jumlah; i++) {
			System.out.println("============================================");
			System.out.println("Transaction ID : " + transactionList.get(i).getTransactionID());
			System.out.println("============================================");
			System.out.println("Customer Name             : " + transactionList.get(i).getCustomerName());
			System.out.println("Shipping Address          : " + transactionList.get(i).getCustomerAddress());
			System.out.println("--------------------------------------------");
			System.out.println("Processor Brand           : " + transactionList.get(i).getProcessorBrand());
			System.out.println("GPU Name                  : " + transactionList.get(i).getPcGPU());
			System.out.println("Internal Memory           : " + transactionList.get(i).getRamSize());
			System.out.println("External Memory           : " + transactionList.get(i).getStorageSize());
			System.out.println("Base Price                : " + String.format("%.1f", transactionList.get(i).getPcPrice()));
			System.out.println("============================================");
			System.out.println(); System.out.println();
		}
		
		System.out.println(); System.out.println();
		System.out.print("Press enter to continue...");
		scan.nextLine();
		System.out.println(); System.out.println();
	}
	
	private boolean checkTransactionIDExists(String TransactionsID) {
		int jumlah = transactionList.size();
		
		for (int k = 0; k < jumlah; k++) {
			if(transactionList.get(k).getTransactionID().equals(TransactionsID)) {
				return true;
			}
		}
		
		return false;
	}
	
	private int getIndexDelete(String TransactionsID) {
		int jumlah = transactionList.size();
		int hasilIndexDelete = 0;
		
		for (int m = 0; m < jumlah; m++) {
			if(transactionList.get(m).getTransactionID().equals(TransactionsID)) {
				hasilIndexDelete = m;
				break;
			}
		}
		
		return hasilIndexDelete;
	}
	
	private void removeTransaction() {
		int jumlah = transactionList.size();
		
		if(jumlah == 0) {
			System.out.println("There's no transaction available."); System.out.println();
			System.out.print("Press enter to continue...");
			scan.nextLine();
			System.out.println(); System.out.println();
			return;
		}
		
		
		for (int j = 0; j < jumlah; j++) {
			System.out.println("============================================");
			System.out.println("Transaction ID : " + transactionList.get(j).getTransactionID());
			System.out.println("============================================");
			System.out.println("Customer Name             : " + transactionList.get(j).getCustomerName());
			System.out.println("Shipping Address          : " + transactionList.get(j).getCustomerAddress());
			System.out.println("--------------------------------------------");
			System.out.println("Processor Brand           : " + transactionList.get(j).getProcessorBrand());
			System.out.println("GPU Name                  : " + transactionList.get(j).getPcGPU());
			System.out.println("Internal Memory           : " + transactionList.get(j).getRamSize());
			System.out.println("External Memory           : " + transactionList.get(j).getStorageSize());
			System.out.println("Base Price                : " + String.format("%.1f", transactionList.get(j).getPcPrice()));
			System.out.println("============================================");
			System.out.println(); System.out.println();
		}
		
		String deleteID;
		do {
			System.out.print("Choose transaction ID to delete (press 0 to cancel) : ");
			deleteID = scan.nextLine();
			
			if(deleteID.equals("0")) {
				System.out.println("Transaction deletion cancelled");
				System.out.println(); System.out.println();
				System.out.print("Press enter to continue...");
				scan.nextLine();
				System.out.println(); System.out.println();
				return;
			}
		}while(!checkTransactionIDExists(deleteID));
		
		int indexDelete;
		indexDelete = getIndexDelete(deleteID);
		transactionList.remove(indexDelete);
		
		System.out.println("Transaction successfully deleted");
		System.out.println(); System.out.println();
		System.out.print("Press enter to continue...");
		scan.nextLine();
		System.out.println(); System.out.println();
	}
	
	public static void main(String[] args) {
		new CompShop31();
	}
}