package Gandam;

import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

public class Gandam {
	Scanner scan = new Scanner(System.in);
	Vector<GandamCollection> gandamList = new Vector<>();
	
	private void gandamLogo() {
		System.out.println("   _____                 _                 ");
		System.out.println("  / ____|               | |                ");
		System.out.println(" | |      __ _ _ __   __| | __ _ _ __ ___  ");
		System.out.println(" | |  __ /_` | '_ \\ / _` |/ _` | '_ ` _ \\ ");
		System.out.println(" | |__\\ \\(_| | | | | (_| | (_| | | | | | |");
		System.out.println("  \\_____/\\__,_|_| |_|\\__,_|\\__,_|_||_| |_|");
		System.out.println(); System.out.println();
	}
	
	public Gandam() {
		int pilihan;
		
		do {
			gandamLogo();
			System.out.println("==========================================");
			System.out.println(); System.out.println();
			System.out.println("1. Assemble new Gandam");
			System.out.println("2. View Gandam Collection");
			System.out.println("3. Disassemble Gandam");
			System.out.println("4. Exit");
			System.out.print(">> ");
			pilihan = scan.nextInt(); scan.nextLine();
			
			switch(pilihan) {
				case 1:
					assembleNewGandam();
					break;
				case 2:
					viewGandamCollection();
					break;
				case 3:
					disassembleGandam();
					break;
			}
		}while(pilihan < 1 || pilihan > 4 || pilihan != 4);
	}
	
	private boolean checkGandamName(String GandamName) {
		if(GandamName.length() >= 5 && GandamName.length() <= 20) {
			return true;
		}else {
			return false;
		}
	}
	
	private boolean checkGandamGrade(String GandamGrade) {
		if(GandamGrade.equals("SD") || GandamGrade.equals("HG") || GandamGrade.equals("MG") || GandamGrade.equals("PG")) {
			return true;
		}else {
			return false;
		}
	}
	
	private boolean checkGandamEquipmentType(String GandamEquipmentType) {
		if(GandamEquipmentType.equals("Weapon") || GandamEquipmentType.equals("Armor") || GandamEquipmentType.equals("Vehicle")) {
			return true;
		}else {
			return false;
		}
	}
	
	private String generateGandamID() {
		String GandamsID;
		Random rand = new Random();
		int number1 = rand.nextInt(10);
		int number2 = rand.nextInt(10);
		int number3 = rand.nextInt(10);
		GandamsID = "EQ" + number1 + number2 + number3;
		
		return GandamsID;
	}
	
	private void assembleNewGandam() {
		String GandamName;
		do {
			System.out.print("Gandam name [5-20 characters]: ");
			GandamName = scan.nextLine();
		}while(!checkGandamName(GandamName));
		
		String GandamGrade;
		do {
			System.out.print("Gandam grade [SD | HG | MG |PG]: ");
			GandamGrade = scan.nextLine();
		}while(!checkGandamGrade(GandamGrade));
		
		if(GandamGrade.equals("SD")) {
			GandamGrade = "SD (Super Deformed)";
		}else if(GandamGrade.equals("HG")) {
			GandamGrade = "HG (High Grade)";
		}else if(GandamGrade.equals("MG")) {
			GandamGrade = "MG (Master Grade)";
		}else if(GandamGrade.equals("PG")) {
			GandamGrade = "PG (Perfect Grade)";
		}
		
		String GandamEquipmentType;
		do {
			System.out.print("Equipment type [Weapon | Armor | Vehicle]: ");
			GandamEquipmentType = scan.nextLine();
		}while(!checkGandamEquipmentType(GandamEquipmentType));
		
		String GandamEquipmentBonus = "";
		if(GandamEquipmentType.equals("Weapon")) {
			GandamEquipmentBonus = "+ 20 Attack";
		}else if(GandamEquipmentType.equals("Armor")) {
			GandamEquipmentBonus = "+ 15 Defense"; 
		}else if(GandamEquipmentType.equals("Vehicle")) {
			GandamEquipmentBonus = "+ 30 Speed";
		}
		
		String GandamID;
		GandamID = generateGandamID();
		
		gandamList.add(new GandamCollection(GandamName, GandamGrade, GandamEquipmentType, GandamEquipmentBonus, GandamID));
	}
	
	private void viewGandamCollection() {
		int jumlah = gandamList.size();
		
		System.out.println();
		if(jumlah == 0) {
			System.out.println("Your Gandam collection is empty!");
			System.out.println();
			System.out.print("Press [enter] to continue...");
			scan.nextLine();
			System.out.println(); System.out.println();
			return;
		}
		
		System.out.println("Gandam Collection");
		System.out.println("=================");
		System.out.println(); System.out.println();
		System.out.println("+======+===================+==========================+===================+");
		System.out.printf("|  %-3s |    %-14s |       %-18s |      %-12s |\n", "No", "Gandam Name", "Gandam Grade", "Equipment");
		System.out.println("+======+===================+==========================+===================+");
		for (int i = 0; i < jumlah; i++) {
			System.out.printf("|  %-3d |    %-14s |      %-19s |      %-12s |\n", (i+1), gandamList.get(i).getGandamName(), gandamList.get(i).getGandamGrade(), gandamList.get(i).getGandamID());
		}
		System.out.println("+======+===================+==========================+===================+");
		
		System.out.println();
		System.out.println("Equipment Information");
		System.out.println("=====================");
		System.out.println(); System.out.println();
		System.out.println("+======+===================+==========================+==========================+");
		System.out.printf("|  %-3s |    %-14s |      %-19s |      %-19s |\n", "No", "Equipment Id", "Equipment Type", "Equipment Bonus");
		System.out.println("+======+===================+==========================+==========================+");
		for (int j = 0; j < jumlah; j++) {
			System.out.printf("|  %-3d |    %-14s |      %-19s |      %-19s |\n", (j+1), gandamList.get(j).getGandamID(), gandamList.get(j).getGandamEquipmentType(), gandamList.get(j).getGandamEquipmentBonus());
		}
		System.out.println("+======+===================+==========================+==========================+");
		
		System.out.println();
		System.out.print("Press [enter] to continue...");
		scan.nextLine();
		System.out.println(); System.out.println();
	}
	
	private boolean checkPilihDelete(int PilihDelete) {
		int jumlah = gandamList.size();
		
		if(PilihDelete < 1 || PilihDelete > jumlah) {
			return false;
		}
		
		return true;
	}
	
	private void disassembleGandam() {
		int jumlah = gandamList.size();
		
		System.out.println();
		if(jumlah == 0) {
			System.out.println("Your Gandam collection is empty!");
			System.out.println();
			System.out.print("Press [enter] to continue...");
			scan.nextLine();
			System.out.println(); System.out.println();
			return;
		}
		
		System.out.println("Gandam Collection");
		System.out.println("=================");
		System.out.println(); System.out.println();
		System.out.println("+======+===================+==========================+===================+");
		System.out.printf("|  %-3s |    %-14s |       %-18s |      %-12s |\n", "No", "Gandam Name", "Gandam Grade", "Equipment");
		System.out.println("+======+===================+==========================+===================+");
		for (int i = 0; i < jumlah; i++) {
			System.out.printf("|  %-3d |    %-14s |      %-19s |      %-12s |\n", (i+1), gandamList.get(i).getGandamName(), gandamList.get(i).getGandamGrade(), gandamList.get(i).getGandamID());
		}
		System.out.println("+======+===================+==========================+===================+");
		
		System.out.println();
		int pilihDelete;
		do {
			System.out.print("Choose Gandam to disassemble [1-" + jumlah +"]: ");
			pilihDelete = scan.nextInt(); scan.nextLine();
		}while(!checkPilihDelete(pilihDelete));
		
		gandamList.remove(pilihDelete-1);
	}
	
	public static void main(String[] args) {
		new Gandam();
	}
}