package Gandam;

public class GandamCollection {
	String gandamName;
	String gandamGrade;
	String gandamEquipmentType;
	String gandamEquipmentBonus;
	String gandamID;
	
	public GandamCollection(String gandamName, String gandamGrade, String gandamEquipmentType,
			String gandamEquipmentBonus, String gandamID) {
		super();
		this.gandamName = gandamName;
		this.gandamGrade = gandamGrade;
		this.gandamEquipmentType = gandamEquipmentType;
		this.gandamEquipmentBonus = gandamEquipmentBonus;
		this.gandamID = gandamID;
	}

	public String getGandamName() {
		return gandamName;
	}

	public void setGandamName(String gandamName) {
		this.gandamName = gandamName;
	}

	public String getGandamGrade() {
		return gandamGrade;
	}

	public void setGandamGrade(String gandamGrade) {
		this.gandamGrade = gandamGrade;
	}

	public String getGandamEquipmentType() {
		return gandamEquipmentType;
	}

	public void setGandamEquipmentType(String gandamEquipmentType) {
		this.gandamEquipmentType = gandamEquipmentType;
	}

	public String getGandamEquipmentBonus() {
		return gandamEquipmentBonus;
	}

	public void setGandamEquipmentBonus(String gandamEquipmentBonus) {
		this.gandamEquipmentBonus = gandamEquipmentBonus;
	}

	public String getGandamID() {
		return gandamID;
	}

	public void setGandamID(String gandamID) {
		this.gandamID = gandamID;
	}
}
