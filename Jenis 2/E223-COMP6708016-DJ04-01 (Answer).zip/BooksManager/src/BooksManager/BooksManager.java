package BooksManager;

import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

public class BooksManager {
	Scanner scan = new Scanner(System.in);
	Vector<Book> bookList = new Vector<>();
	
	public BooksManager() {
		int pilihan;
		
		do {
			System.out.println("Book's Manager");
			System.out.println("1. View Books");
			System.out.println("2. Insert Book");
			System.out.println("3. Delete Book");
			System.out.println("4. Exit");
			System.out.print(">> ");
			pilihan = scan.nextInt(); scan.nextLine();
			
			switch(pilihan) {
				case 1:
					viewBooks();
					break;
				case 2:
					insertBook();
					break;
				case 3:
					deleteBook();
					break;
			}
		}while(pilihan < 1 || pilihan > 4 || pilihan != 4);
	}
	
	private void viewBooks() {
		int jumlah = bookList.size();
		
		if(jumlah == 0) {
			System.out.println("There is no book yet.");
			System.out.print("Press enter to continue...");
			scan.nextLine();
			System.out.println(); System.out.println();
			return;
		}
		
		System.out.println("|=======================================================================|");
		System.out.printf("| %-5s | %-5s | %-10s | %-8s | %-10s | %-16s |\n","No", "Id", "Title", "Type", "Price", "Total Chapter(s)");
		System.out.println("|=======================================================================|");
		for (int i = 0; i < jumlah; i++) {
			System.out.printf("| %-5d | %-5s | %-10s | %-8s | %-10d | %-16d |\n",(i+1), bookList.get(i).getBookID(), bookList.get(i).getBookTitle(), bookList.get(i).getBookType(), bookList.get(i).getBookPrice(), bookList.get(i).getBookChapterNumber());
		}
		System.out.println("|=======================================================================|");
		System.out.print("Press enter to continue...");
		scan.nextLine();
		System.out.println(); System.out.println();
	}
	
	private boolean checkBookTitle(String BookTitle) {
		if(BookTitle.length() >= 5 && BookTitle.length() <= 10) {
			return true;
		}else {
			return false;
		}
	}
	
	private boolean checkBookType(String BookType) {
		if(BookType.equals("Novel") || BookType.equals("Comic")) {
			return true;
		}else {
			return false;
		}
	}
	
	private boolean checkBookChapterNumber(int BookChapterNumber) {
		if(BookChapterNumber >= 1 && BookChapterNumber <= 10) {
			return true;
		}else {
			return false;
		}
	}
	
	private int getBookPrice(String BookType, int BookChapterNumber) {
		int BookPrices = 0;
		if(BookType.equals("Novel")) {
			BookPrices = 100000 + (BookChapterNumber * 1000);
		}else if(BookType.equals("Comic")) {
			BookPrices = 50000  + (BookChapterNumber * 1000);
		}
		
		return BookPrices;
	}
	
	private String generateBookID() {
		String BooksID;
		Random rand = new Random();
		int number1 = rand.nextInt(10);
		int number2 = rand.nextInt(10);
		int number3 = rand.nextInt(10);
		BooksID = "BK" + number1 + number2 + number3;
		
		return BooksID;
	}
	
	private void insertBook() {
		System.out.println();
		String BookTitle;
		do {
			System.out.print("Input title [5-10 Characters]: ");
			BookTitle = scan.nextLine();
		}while(!checkBookTitle(BookTitle));
		
		String BookType;
		do {
			System.out.print("Input type [Novel|Comic Case sensitive]: ");
			BookType = scan.nextLine();
		}while(!checkBookType(BookType));
		
		int BookChapterNumber;
		do {
			System.out.print("Input number of chapter(s) [1-10]: ");
			BookChapterNumber = scan.nextInt(); scan.nextLine();
		}while(!checkBookChapterNumber(BookChapterNumber));
		
		int BookPrice;
		BookPrice = getBookPrice(BookType, BookChapterNumber);
		
		String BookID;
		BookID = generateBookID();
		
		bookList.add(new Book(BookID, BookTitle, BookType, BookPrice, BookChapterNumber));
		System.out.println("Book created!");
		System.out.print("Press enter to continue...");
		scan.nextLine();
		System.out.println(); System.out.println();
	}
	
	private boolean checkPilihDelete(int PilihDelete) {
		int jumlah = bookList.size();
		
		if(PilihDelete < 1 || PilihDelete > jumlah) {
			return false;
		}
		
		return true;
	}
	
	private void deleteBook() {
		int jumlah = bookList.size();
		
		if(jumlah == 0) {
			System.out.println("There is no book yet.");
			System.out.print("Press enter to continue...");
			scan.nextLine();
			System.out.println(); System.out.println();
			return;
		}
		
		System.out.println("|=======================================================================|");
		System.out.printf("| %-5s | %-5s | %-10s | %-8s | %-10s | %-16s |\n","No", "Id", "Title", "Type", "Price", "Total Chapter(s)");
		System.out.println("|=======================================================================|");
		for (int i = 0; i < jumlah; i++) {
			System.out.printf("| %-5d | %-5s | %-10s | %-8s | %-10d | %-16d |\n",(i+1), bookList.get(i).getBookID(), bookList.get(i).getBookTitle(), bookList.get(i).getBookType(), bookList.get(i).getBookPrice(), bookList.get(i).getBookChapterNumber());
		}
		System.out.println("|=======================================================================|");
		
		System.out.println();
		int indexDelete;
		do {
			System.out.print("Choose index to be deleted [1.." + jumlah +"]: ");
			indexDelete = scan.nextInt(); scan.nextLine();
			System.out.println();
		}while(!checkPilihDelete(indexDelete));
		
		bookList.remove(indexDelete-1);
	}

	public static void main(String[] args) {
		new BooksManager();
	}
}
