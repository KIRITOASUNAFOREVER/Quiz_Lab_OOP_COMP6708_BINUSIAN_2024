package BooksManager;

public class Book {
	String bookID;
	String bookTitle;
	String bookType;
	int bookPrice;
	int bookChapterNumber;
	
	public Book(String bookID, String bookTitle, String bookType, int bookPrice, int bookChapterNumber) {
		super();
		this.bookID = bookID;
		this.bookTitle = bookTitle;
		this.bookType = bookType;
		this.bookPrice = bookPrice;
		this.bookChapterNumber = bookChapterNumber;
	}

	public String getBookID() {
		return bookID;
	}

	public void setBookID(String bookID) {
		this.bookID = bookID;
	}

	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	public String getBookType() {
		return bookType;
	}

	public void setBookType(String bookType) {
		this.bookType = bookType;
	}

	public int getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(int bookPrice) {
		this.bookPrice = bookPrice;
	}

	public int getBookChapterNumber() {
		return bookChapterNumber;
	}

	public void setBookChapterNumber(int bookChapterNumber) {
		this.bookChapterNumber = bookChapterNumber;
	}
}
